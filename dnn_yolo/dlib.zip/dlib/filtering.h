// Copyright (C) 2012  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_FILTERiNG_HEADER
#define DLIB_FILTERiNG_HEADER

#include "filtering/kalman_filter.h"
#include "filtering/rls_filter.h"

#endif // DLIB_FILTERiNG_HEADER



