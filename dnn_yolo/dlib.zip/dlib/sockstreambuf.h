// Copyright (C) 2003  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_SOCKSTREAMBUf_H_h_
#define DLIB_SOCKSTREAMBUf_H_h_

#include "sockstreambuf/sockstreambuf.h"
#include "sockstreambuf/sockstreambuf_unbuffered.h"


#endif // DLIB_SOCKSTREAMBUf_H_h_

