#ifndef DLIB_REVISION_H
// Version:  19.21
// Date:     Sat Aug 8 15:26:07 EDT 2020
// Git Changeset ID:  9117bd784328d9ac40ffa1f9cf487633a8a715d7
#define DLIB_MAJOR_VERSION  19
#define DLIB_MINOR_VERSION  21
#define DLIB_PATCH_VERSION  0
#endif
